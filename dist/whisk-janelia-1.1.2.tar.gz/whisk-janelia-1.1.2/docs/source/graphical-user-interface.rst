.. _gui:

========================
Graphical User Interface
========================

.. todo::

  GUI docs
