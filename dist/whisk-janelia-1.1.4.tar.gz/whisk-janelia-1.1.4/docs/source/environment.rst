.. environment:

********************************
Useful environment variables
********************************

.. envvar:: PATH

   Your operating system uses this variable to determine which paths to search
   to find executable commands.  If you are unsure how to set this for your
   operating system, you should ask someone for help.  Instructions are available
   online for `Mac OS X`_ and Windows_.

   .. _`Mac OS X`: http://onlamp.com/pub/a/mac/2004/02/24/bash.html

   .. _Windows: http://support.microsoft.com/kb/310519

