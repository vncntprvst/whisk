.. contents:

Contents
========

.. toctree::
   :maxdepth: 3

   index.rst

   install.rst

   tutorial.rst

   command-line-tools.rst

   graphical-user-interface.rst

   glossary.rst

   special-files.rst

   todolist.rst

   environment.rst

.. 
   command-line-tools.rst

   matlab-interface.rst

   python-interface.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
* :ref:`modindex`
* :doc:`glossary`
* :doc:`todolist`
* :doc:`environment`
